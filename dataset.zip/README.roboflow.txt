
placa - v1 data
==============================

This dataset was exported via roboflow.ai on October 4, 2021 at 7:11 PM GMT

It includes 400 images.
Placa are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


